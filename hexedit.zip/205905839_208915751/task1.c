#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define  NAME_LEN  128
#define  BUF_SZ    10000
int unit_size = sizeof(int);

typedef struct {
  char debug_mode; // 0 is off; 1 is on;
  char file_name[NAME_LEN];
  int unit_size;
  unsigned char mem_buf[BUF_SZ];
  size_t mem_count;
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;

char* unit_to_format(int unit,int size) {
    static char* formats[] = {"%hhX\n", "%hX\n", "No such unit", "%X\n"};
    return formats[size-1];
}
void print_units(FILE* output, char* buffer, int count,int size) {
    char* end = buffer + unit_size*count;
    while (buffer < end) {
        //print ints
        int var = *((int*)(buffer));
        fprintf(output, unit_to_format(unit_size,size), var);
        buffer += unit_size;
    }
}
char* unit_to_format_dec(int unit,int size) {
    static char* formats[] = {"%hhd\n", "%hd\n", "No such unit", "%d\n"};
    return formats[size-1];
}
void print_units_dec(FILE* output, char* buffer, int count,int size) {
    char* end = buffer + unit_size*count;
    while (buffer < end) {
        //print ints
        int var = *((int*)(buffer));
        fprintf(output, unit_to_format_dec(unit_size,size), var);
        buffer += unit_size;
    }
}
struct fun_desc{
    char *name;
    void (*fun)(state*);
};

void debugPrint(state* s)
{
    //unit_size, file_name, and mem_count
    printf("unit size is: %d\n",s->unit_size);
    printf("file name is: %s\n",s->file_name);
    printf("memory count is: %d\n",s->mem_count);
}
void ToggleDebugMode(state* s){
    if(s->debug_mode-'1'==0)
    {
        s->debug_mode='0';
        printf("Debug flag is now off.\n");
    }
    else{
         s->debug_mode='1';
        printf("Debug flag is now on.\n");
    }

}
void SetFileName(state* s){
    //"Debug: file name set to 'file_name' "
    
    char newName[128];
    fgets(newName,128,stdin);
    sscanf(newName,"%s",s->file_name);
    
    
   
    if (s->debug_mode-'1'==0)
    {
        printf("Debug: file name set to %s \n",s->file_name);
    }

}
void SetUnitSize(state* s){
    printf("choose a size number : 1,2,4\n");
    char in[1024];
    int newSizeUnit;
    newSizeUnit=atoi(fgets(in,1024,stdin));;
    if((newSizeUnit==1)|(newSizeUnit==2)|(newSizeUnit==4)){

        s->unit_size=newSizeUnit;
        if (s->debug_mode-'1'==0)
        {
            printf("Debug: set size to %d \n",s->unit_size);
        }
    }
    else{
        printf("incompatible unit size. \n");
        return;
    }


}
void Quit(state* s){
    if (s->debug_mode-'1'==0)
        {
            printf("quitting\n");
            free(s);

        }
    free(s);
	exit(0);
}
void LoadIntoMemory(state* s){
    if (strcmp(s->file_name,"")==0)
    {
        printf("error message: file name empty\n");
        return;
    }
    FILE* MYFILE=fopen(s->file_name,"r");
    if(MYFILE==NULL)
    {
        printf("error message: cannot open file\n");
        return;
    }
    printf("Please enter <location> <length>\n");
    char input[1024];
    int length;
    int location;
    fgets(input,1024,stdin);
    sscanf(input,"%X %d",&location,&length);
    fseek(MYFILE,location,SEEK_SET);
    fread(s->mem_buf,s->unit_size,length,MYFILE);
    printf("Loaded %d units into memory\n",length*s->unit_size);
    fclose(MYFILE);
	
}
void MemoryDisplay(state* s){
   
    printf("Enter address and length\n");
    char input[1024];
    int u;
    int addr;
    fgets(input,1024,stdin);
    sscanf(input,"%X %d",&addr,&u);
    
    if (addr==0)
    {
        printf("HexaDecimal\n");
        print_units(stdout,(char*)s->mem_buf,u,s->unit_size);
        printf("Decimal\n");
        print_units_dec(stdout,(char*)s->mem_buf,u,s->unit_size);

    }
    else {
        printf("HexaDecimal\n");
        char* loc= ( char*)addr; 
        print_units(stdout,loc,u,s->unit_size);
        printf("Decimal\n");
        print_units_dec(stdout,loc,u,s->unit_size);
    }
    

}

void SaveIntoFile(state* s){
    printf("Please enter <source-address> <target-location> <length>\n");
    char input[1024];
    int source_address;
    int target_location;
    int length;
    fgets(input,1024,stdin);
    sscanf(input,"%X %X %d",&source_address,&target_location,&length);
    if (strcmp(s->file_name,"")==0)
    {
        printf("error message: file name empty\n");
        return;
    }
    FILE* MY_FILE=fopen(s->file_name,"rb+");
    if(MY_FILE==NULL)
    {
        printf("error message: cannot open file\n");
        return;
    }
    if (source_address==0)
    {
        fseek(MY_FILE,target_location,SEEK_SET);
        fwrite((char*)s->mem_buf,s->unit_size, length, MY_FILE);

    }
    else {
        char* loc= ( char*)source_address;
        fseek(MY_FILE,target_location,SEEK_SET);
        fwrite(loc,s->unit_size, length, MY_FILE);
    }
    fclose(MY_FILE);
}
void MemoryModify(state* s){
    printf("Please enter <location> <val>\n");
    char input[1024];
    int location;
    int val;
    fgets(input,1024,stdin);
    sscanf(input,"%X %X",&location,&val);
    if(s->debug_mode){
        printf("Debug: recieved from the user location %X and val %X", location,val);
    }
    memcpy(s->mem_buf+location,&val,s->unit_size);
}

int main(){
    state* s=malloc(sizeof(state));
    struct fun_desc menu[]={{"Toggle Debug Mode",ToggleDebugMode},{"Set File Name",SetFileName},
    {"Set Unit Size",SetUnitSize},{"Load Into Memory",LoadIntoMemory},{"Memory Display",MemoryDisplay},
    {"Save Into File",SaveIntoFile},{"Memory Modify",MemoryModify},{"Quit",Quit},{NULL,NULL}};
    while (1)
	    {
            int i=0;
            if (s->debug_mode-'1'==0)
            {
                debugPrint(s);
            }
            while (menu[i].name!=NULL)
            {
                printf("%d- %s\n",i,menu[i].name);
                i++;
            }
            char in[1024];
            int option;
            option=atoi(fgets(in,1024,stdin));
            if ((option>i)||(option<0))
            {
                printf("option not valid\n");
            }
            else
            {
                menu[option].fun(s);
            }

	    }
        free(s);
}