int digit_counter (char* number)
{
    int i=0;
    int cnt=0;
    while (number[i]!=0)
    {
        if ((number[i]>='0')&&(number[i]<='9'))
        {
            cnt++;
        }
         i++;
    }
    return cnt;
}
int main(){return 0;}